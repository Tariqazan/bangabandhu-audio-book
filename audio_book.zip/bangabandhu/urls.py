from django.urls import path
from .views import *

urlpatterns = [
    path('audiobook/', AudioBookListCreateView.as_view()),
    path('audiobook/<int:pk>/', AudioBookRetrieveUpdateDestroyView.as_view()),
]
