from rest_framework import generics
from .models import AudioBook
from .serializers import AudioBookSerializer

# Create your views here.


class AudioBookListCreateView(generics.ListCreateAPIView):
    queryset = AudioBook.objects.all()
    serializer_class = AudioBookSerializer


class AudioBookRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = AudioBook.objects.all()
    serializer_class = AudioBookSerializer
