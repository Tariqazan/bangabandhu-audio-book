from rest_framework import serializers
from .models import AudioBook

class AudioBookSerializer(serializers.ModelSerializer):
    class Meta:
        model = AudioBook
        fields = ('id', 'name', 'language', 'translated_name', 'created_at', 'updated_at')
